// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: https://codemirror.net/5/LICENSE

// Swift mode created by Michael Kaminsky https://github.com/mkaminsky11

(function(mod) {
  if (typeof exports == "object" && typeof module == "object")
    mod(require("../../lib/codemirror"))
  else if (typeof define == "function" && define.amd)
    define(["../../lib/codemirror"], mod)
  else
    mod(CodeMirror)
})(function(CodeMirror) {
  "use strict"

  function wordSet(words) {
    var set = {}
    for (var i = 0; i < words.length; i++) set[words[i]] = true
    return set
  }

  var keywords = wordSet(["_","if","elseif","thread","class","func","self","exit","guard","loop","match","async","obj","and","or","coroutine",
                          "__COLUMN__","__FILE__","__FUNCTION__","__LINE__"])
  var definingKeywords = wordSet(["thread","func","class"])
  var atoms = wordSet(["true","false","nil","self","super","_"])
  var atoms2 = wordSet(["for","in","loop","to","return","break","if","elseif"])
  var types = wordSet(["tcplistener","tcpaccept","tcpconnect","tcpsend","tcpreceive","tcpdisconnect","terminalenableraw","terminaldisableraw","download","httpget","ncwebserver",
  "rawget","rawgetfile","restrictionmode","debugmode","math" ,"calc","run","trim","minutes_in_ms","hours_in_ms","days_in_ms","weeks_in_ms","months_in_ms","years_in_ms","stringtobase64",
  "base64tostring","unzip","zip","memusage","memstats","memorystatus","objtojson","objfromjson","dirdelete","dirmove","arrayreverse","arrayfirstout","arraylastout","arraypush","arraypushroll",
  "terminalinput","filecopy","filedelete","filemove","round","random","dircreate","filesizebytes","filesize","curl","iscode","inpool","pooladd","poolremove","arraysort","stackpush","sleep",
  "hextostring","stringtohex","stackpop","delobj","objdel","objparents","setobjprop","getobjprop","setobj","inobj","delobjprop","stringtoeval","isfunction","exec","sheet","code","cin",
  "browseropen","chain","cwrite" ,"print","cwriteraw" ,"printraw","timerinit","timerdiff","fread" ,"fileread","fwrite","filewrite","splitselect","file_read_utf8","listdir",
  "dirtolist" ,"dirlist","split","instring","replace","trimleft","trimright","fromleft","fromright","save","load","setvar","getvar","exit","arrayfilter","arraysearch","arrayshuffle","math","cat",
  "decode_html_url","html_encode","nodespawnsquare","nodesetposition","nodesetrotation","nodesetscale","nodegetscale","nodegetrotation","nodegetposition","textureload","textureset",
"camerasetposition","nodedelete","spriteload","spritesetanimation","spritegetanimations","eguiwindow","eguibutton","eguilabel","eguislider","eguicombo",
"eguiopenfilebutton","eguisavefilebutton","eguicolorpicker","eguiclosewindow","eguiopenwindow","eguiradio","eguiinput","eguicheckbox","eguihyperlink","nodesetcolor"])
  var operators = "+-/*%=|&<>~^?!"
  var punc = ":;,.(){}[]"
  var binary = /^\-?0b[01][01_]*/
  var octal = /^\-?0o[0-7][0-7_]*/
  var hexadecimal = /^\-?0x[\dA-Fa-f][\dA-Fa-f_]*(?:(?:\.[\dA-Fa-f][\dA-Fa-f_]*)?[Pp]\-?\d[\d_]*)?/
  var decimal = /^\-?\d[\d_]*(?:\.\d[\d_]*)?(?:[Ee]\-?\d[\d_]*)?/
  var identifier = /^\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1/
  var property = /^\.(?:\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1)/
  var instruction = /^\#[A-Za-z]+/
  var attribute = /^@(?:\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1)/
  //var regexp = /^\/(?!\s)(?:\/\/)?(?:\\.|[^\/])+\//

  function tokenBase(stream, state, prev) {
    if (stream.sol()) state.indented = stream.indentation()
    if (stream.eatSpace()) return null

    var ch = stream.peek()
    if (ch == "/") {
      if (stream.match("//")) {
        stream.skipToEnd()
        return "comment"
      }
      if (stream.match("/*")) {
        state.tokenize.push(tokenComment)
        return tokenComment(stream, state)
      }
    }
    if (stream.match(instruction)) return "builtin"
    if (stream.match(attribute)) return "attribute"
    if (stream.match(binary)) return "number"
    if (stream.match(octal)) return "number"
    if (stream.match(hexadecimal)) return "number"
    if (stream.match(decimal)) return "number"
    if (stream.match(property)) return "property"
    if (operators.indexOf(ch) > -1) {
      stream.next()
      return "operator"
    }
    if (punc.indexOf(ch) > -1) {
      stream.next()
      stream.match("..")
      return "punctuation"
    }
    var stringMatch
    if (stringMatch = stream.match(/("""|"|')/)) {
      var tokenize = tokenString.bind(null, stringMatch[0])
      state.tokenize.push(tokenize)
      return tokenize(stream, state)
    }

    if (stream.match(identifier)) {
      var ident = stream.current()
      if (types.hasOwnProperty(ident)) return "variable-2"
      if (atoms.hasOwnProperty(ident)) return "atom"
      if (atoms2.hasOwnProperty(ident)) return "atom2"
      if (keywords.hasOwnProperty(ident)) {
        if (definingKeywords.hasOwnProperty(ident))
          state.prev = "define"
        return "keyword"
      }
      if (prev == "define") return "def"
      return "variable"
    }

    stream.next()
    return null
  }

  function tokenUntilClosingParen() {
    var depth = 0
    return function(stream, state, prev) {
      var inner = tokenBase(stream, state, prev)
      if (inner == "punctuation") {
        if (stream.current() == "(") ++depth
        else if (stream.current() == ")") {
          if (depth == 0) {
            stream.backUp(1)
            state.tokenize.pop()
            return state.tokenize[state.tokenize.length - 1](stream, state)
          }
          else --depth
        }
      }
      return inner
    }
  }

  function tokenString(openQuote, stream, state) {
    var singleLine = openQuote.length == 1
    var ch, escaped = false
    while (ch = stream.peek()) {
      if (escaped) {
        stream.next()
        if (ch == "(") {
          state.tokenize.push(tokenUntilClosingParen())
          return "string"
        }
        escaped = false
      } else if (stream.match(openQuote)) {
        state.tokenize.pop()
        return "string"
      } else {
        stream.next()
        escaped = ch == "\\"
      }
    }
    if (singleLine) {
      state.tokenize.pop()
    }
    return "string"
  }

  function tokenComment(stream, state) {
    var ch
    while (ch = stream.next()) {
      if (ch === "/" && stream.eat("*")) {
        state.tokenize.push(tokenComment)
      } else if (ch === "*" && stream.eat("/")) {
        state.tokenize.pop()
        break
      }
    }
    return "comment"
  }

  function Context(prev, align, indented) {
    this.prev = prev
    this.align = align
    this.indented = indented
  }

  function pushContext(state, stream) {
    var align = stream.match(/^\s*($|\/[\/\*])/, false) ? null : stream.column() + 1
    state.context = new Context(state.context, align, state.indented)
  }

  function popContext(state) {
    if (state.context) {
      state.indented = state.context.indented
      state.context = state.context.prev
    }
  }

  CodeMirror.defineMode("swift", function(config) {
    return {
      startState: function() {
        return {
          prev: null,
          context: null,
          indented: 0,
          tokenize: []
        }
      },

      token: function(stream, state) {
        var prev = state.prev
        state.prev = null
        var tokenize = state.tokenize[state.tokenize.length - 1] || tokenBase
        var style = tokenize(stream, state, prev)
        if (!style || style == "comment") state.prev = prev
        else if (!state.prev) state.prev = style

        if (style == "punctuation") {
          var bracket = /[\(\[\{]|([\]\)\}])/.exec(stream.current())
          if (bracket) (bracket[1] ? popContext : pushContext)(state, stream)
        }

        return style
      },

      indent: function(state, textAfter) {
        var cx = state.context
        if (!cx) return 0
        var closing = /^[\]\}\)]/.test(textAfter)
        if (cx.align != null) return cx.align - (closing ? 1 : 0)
        return cx.indented + (closing ? 0 : config.indentUnit)
      },

      electricInput: /^\s*[\)\}\]]$/,

      lineComment: "//",
      blockCommentStart: "/*",
      blockCommentEnd: "*/",
      fold: "brace",
      closeBrackets: "()[]{}''\"\"``"
    }
  })

  CodeMirror.defineMIME("text/x-swift","swift")
});
