document.addEventListener("DOMContentLoaded", function () {
  const rowsPerPage = 13;
  const tableBody = document.querySelector(".table tbody");
  const pagination = document.querySelector(".pagination .btn-group");
  const maxVisibleButtons = 11;
  const debugMode = false;

  if (debugMode) {
    for (let i = 1; i <= 200; i++) {
      const row = document.createElement("tr");
      for (let j = 0; j < 7; j++) {
        const cell = document.createElement("td");
        cell.textContent = `Cel ${j + 1} Rij ${i}`;
        row.appendChild(cell);
      }
      tableBody.appendChild(row);
    }
  }

  const rows = Array.from(document.querySelectorAll(".table tbody tr"));
  const totalPages = Math.ceil(rows.length / rowsPerPage);

  function displayPage(page) {
    rows.forEach((row, index) => {
      row.style.display =
        index >= (page - 1) * rowsPerPage && index < page * rowsPerPage
          ? "table-row"
          : "none";
    });

    pagination.querySelectorAll("button").forEach((btn) => {
      const num = parseInt(btn.dataset.page);
      if (!isNaN(num)) {
        btn.classList.toggle("active", num === page);
      }
    });
  }

  function createPagination(currentPage) {
    pagination.innerHTML = "";

    function createButton(label, targetPage, isDisabled = false, isActive = false) {
      const btn = document.createElement("button");
      btn.className = "btn";
      btn.textContent = label;
      btn.dataset.page = targetPage;

      if (isActive) btn.classList.add("active");
      if (isDisabled) {
        btn.disabled = true;
        btn.classList.add("disabled");
      } else {
        btn.addEventListener("click", () => {
          displayPage(targetPage);
          createPagination(targetPage);
        });
      }
      pagination.appendChild(btn);
    }

    createButton("First", 1, currentPage === 1);
    createButton("Previous", currentPage - 1, currentPage === 1);

    const half = Math.floor(maxVisibleButtons / 2);
    let startPage = Math.max(1, currentPage - half);
    let endPage = Math.min(totalPages, startPage + maxVisibleButtons - 1);

    if (endPage - startPage + 1 < maxVisibleButtons) {
      startPage = Math.max(1, endPage - maxVisibleButtons + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      createButton(i.toString(), i, false, i === currentPage);
    }

    createButton("Next", currentPage + 1, currentPage === totalPages);
    createButton("Last", totalPages, currentPage === totalPages);
  }

  if (rows.length > 0) {
    createPagination(1);
    displayPage(1);
  } else {
    console.warn("Geen rijen gevonden in de tabel.");
  }
});
