function uploadBase64(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Get the base64 string from the selected file
    var reader = new FileReader();
    reader.onload = function (e) {
        document.getElementById("base64Input").value = e.target.result;
    };

    // For debugging purposes, you might want to display the Base64 string as an image
    const img = document.createElement('img');
    img.src = 'data:image/jpeg;base64,' + file.toString();
    document.body.appendChild(img);
}
